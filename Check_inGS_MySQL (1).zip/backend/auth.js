import jwt from 'jsonwebtoken'
import crypto from 'crypto'
import { pool } from './db.js'

export function signAccessToken(user){
  return jwt.sign({ userId:user.id, role:user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '15m' })
}
export function authRequired(req,res,next){
  const header=req.headers.authorization||''
  const token=header.startsWith('Bearer ')?header.slice(7):null
  if(!token)return res.status(401).json({message:'Chưa đăng nhập'})
  try{req.auth=jwt.verify(token,process.env.JWT_SECRET);next()}
  catch{return res.status(401).json({message:'Phiên đăng nhập đã hết hạn'})}
}
export async function createRefreshToken(userId){
  const raw=crypto.randomBytes(48).toString('hex')
  const hash=crypto.createHash('sha256').update(raw).digest('hex')
  const days=Number(process.env.REFRESH_TOKEN_DAYS||30)
  await pool.execute('INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY))',[userId,hash,days])
  return raw
}