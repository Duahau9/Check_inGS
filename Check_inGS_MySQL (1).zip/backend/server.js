import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import bcrypt from 'bcryptjs'
import crypto from 'crypto'
import { pool } from './db.js'
import { authRequired,signAccessToken,createRefreshToken } from './auth.js'

dotenv.config()
const app=express()
app.use(cors({origin:true,credentials:true}))
app.use(express.json())

const publicUser=u=>({id:u.id,full_name:u.full_name,email:u.email,role:u.role,phone:u.phone,avatar_url:u.avatar_url})

app.get('/api/health',async(_req,res)=>{
 try{await pool.query('SELECT 1');res.json({ok:true,database:true})}
 catch(e){res.status(500).json({ok:false,database:false,message:e.message})}
})

app.post('/api/auth/register',async(req,res)=>{
 const {full_name,email,password,role='tutor',phone=null}=req.body
 if(!full_name||!email||!password)return res.status(400).json({message:'Vui lòng nhập họ tên, email và mật khẩu'})
 if(password.length<6)return res.status(400).json({message:'Mật khẩu tối thiểu 6 ký tự'})
 if(!['tutor','parent'].includes(role))return res.status(400).json({message:'Vai trò không hợp lệ'})
 try{
  const [exists]=await pool.execute('SELECT id FROM users WHERE email=? LIMIT 1',[email.trim().toLowerCase()])
  if(exists.length)return res.status(409).json({message:'Email đã được đăng ký'})
  const hash=await bcrypt.hash(password,12)
  const [r]=await pool.execute('INSERT INTO users(full_name,email,password_hash,role,phone) VALUES(?,?,?,?,?)',[full_name,email.trim().toLowerCase(),hash,role,phone])
  const user={id:r.insertId,full_name,email:email.trim().toLowerCase(),role,phone}
  const accessToken=signAccessToken(user)
  await createRefreshToken(user.id)
  res.status(201).json({user,accessToken})
 }catch(e){res.status(500).json({message:'Không thể tạo tài khoản',detail:e.message})}
})

app.post('/api/auth/login',async(req,res)=>{
 const {email,password}=req.body
 try{
  const [rows]=await pool.execute('SELECT * FROM users WHERE email=? AND is_active=1 LIMIT 1',[String(email||'').trim().toLowerCase()])
  if(!rows.length)return res.status(401).json({message:'Email hoặc mật khẩu không đúng'})
  const user=rows[0]
  const ok=await bcrypt.compare(password||'',user.password_hash)
  if(!ok)return res.status(401).json({message:'Email hoặc mật khẩu không đúng'})
  await pool.execute('UPDATE users SET last_login_at=UTC_TIMESTAMP() WHERE id=?',[user.id])
  const accessToken=signAccessToken(user)
  await createRefreshToken(user.id)
  res.json({user:publicUser(user),accessToken})
 }catch(e){res.status(500).json({message:'Đăng nhập thất bại',detail:e.message})}
})

app.get('/api/auth/me',authRequired,async(req,res)=>{
 const [rows]=await pool.execute('SELECT id,full_name,email,role,phone,avatar_url,is_active FROM users WHERE id=? LIMIT 1',[req.auth.userId])
 if(!rows.length)return res.status(404).json({message:'Không tìm thấy tài khoản'})
 res.json({user:rows[0]})
})

app.post('/api/auth/logout',authRequired,async(req,res)=>{
 // Access JWT is stateless; refresh tokens are revoked so future refresh cannot recreate a session.
 await pool.execute('UPDATE refresh_tokens SET revoked_at=UTC_TIMESTAMP() WHERE user_id=? AND revoked_at IS NULL',[req.auth.userId])
 res.json({ok:true})
})

app.post('/api/attendance/check-in',authRequired,async(req,res)=>{
 const {latitude,longitude,accuracy}=req.body
 if(!Number.isFinite(Number(latitude))||!Number.isFinite(Number(longitude)))return res.status(400).json({message:'GPS không hợp lệ'})
 const tutorId=req.auth.userId
 const [open]=await pool.execute(`SELECT a.id FROM attendance a WHERE a.tutor_id=? AND a.status IN ('working','checked_in') ORDER BY a.id DESC LIMIT 1`,[tutorId])
 if(open.length)return res.status(409).json({message:'Bạn đang có một buổi học chưa check-out'})
 const [r]=await pool.execute(`INSERT INTO attendance(tutor_id,student_id,check_in_at,check_in_lat,check_in_lng,check_in_accuracy,status)
 VALUES(?,NULL,UTC_TIMESTAMP(),?,?,?,'working')`,[tutorId,latitude,longitude,accuracy??null])
 res.json({id:r.insertId,status:'working'})
})

app.post('/api/attendance/check-out',authRequired,async(req,res)=>{
 const {latitude,longitude,accuracy}=req.body
 const [rows]=await pool.execute(`SELECT * FROM attendance WHERE tutor_id=? AND status IN ('working','checked_in') ORDER BY id DESC LIMIT 1`,[req.auth.userId])
 if(!rows.length)return res.status(409).json({message:'Không có buổi học đang check-in'})
 const a=rows[0]
 await pool.execute(`UPDATE attendance SET check_out_at=UTC_TIMESTAMP(),check_out_lat=?,check_out_lng=?,check_out_accuracy=?,status='completed',total_seconds=TIMESTAMPDIFF(SECOND,check_in_at,UTC_TIMESTAMP()) WHERE id=?`,[latitude,longitude,accuracy??null,a.id])
 res.json({id:a.id,status:'completed'})
})

app.get('/api/attendance/today',authRequired,async(req,res)=>{
 const [rows]=await pool.execute(`SELECT *,TIMESTAMPDIFF(SECOND,check_in_at,COALESCE(check_out_at,UTC_TIMESTAMP())) AS live_seconds FROM attendance WHERE tutor_id=? ORDER BY id DESC LIMIT 1`,[req.auth.userId])
 res.json({attendance:rows[0]||null})
})

app.get('/api/attendance/history',authRequired,async(req,res)=>{
 const [rows]=await pool.execute(`SELECT * FROM attendance WHERE tutor_id=? ORDER BY check_in_at DESC`,[req.auth.userId])
 res.json(rows)
})

app.get('/api/notifications',authRequired,async(req,res)=>{
 const [rows]=await pool.execute('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100',[req.auth.userId])
 res.json({notifications:rows})
})

const port=Number(process.env.PORT||3001)
app.listen(port,()=>console.log(`Gia Su Check-in API running on :${port}`))