CREATE DATABASE IF NOT EXISTS giasu_checkin
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE giasu_checkin;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','tutor','parent') NOT NULL DEFAULT 'tutor',
  phone VARCHAR(20) NULL,
  avatar_url VARCHAR(500) NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role(role)
) ENGINE=InnoDB;

CREATE TABLE students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  date_of_birth DATE NULL,
  gender ENUM('male','female','other') NULL,
  school VARCHAR(150) NULL,
  grade VARCHAR(30) NULL,
  address VARCHAR(255) NULL,
  parent_id INT UNSIGNED NULL,
  phone VARCHAR(20) NULL,
  note TEXT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_students_parent FOREIGN KEY(parent_id) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tutor_students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tutor_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tutor_student(tutor_id,student_id),
  CONSTRAINT fk_ts_tutor FOREIGN KEY(tutor_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ts_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE classes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tutor_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  class_date DATE NOT NULL,
  scheduled_start TIME NOT NULL,
  scheduled_end TIME NOT NULL,
  subject VARCHAR(100) NULL,
  location VARCHAR(255) NULL,
  note TEXT NULL,
  status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_classes_tutor FOREIGN KEY(tutor_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_classes_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
  INDEX idx_classes_date(class_date),
  INDEX idx_classes_tutor_date(tutor_id,class_date)
) ENGINE=InnoDB;

CREATE TABLE attendance (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  class_id INT UNSIGNED NULL,
  tutor_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NULL,
  check_in_at DATETIME NULL,
  check_out_at DATETIME NULL,
  check_in_lat DECIMAL(10,7) NULL,
  check_in_lng DECIMAL(10,7) NULL,
  check_in_accuracy DECIMAL(10,2) NULL,
  check_out_lat DECIMAL(10,7) NULL,
  check_out_lng DECIMAL(10,7) NULL,
  check_out_accuracy DECIMAL(10,2) NULL,
  check_in_address VARCHAR(500) NULL,
  check_out_address VARCHAR(500) NULL,
  total_seconds INT UNSIGNED NULL,
  status ENUM('not_started','working','completed','late','absent','cancelled','checked_in','checked_out') NOT NULL DEFAULT 'not_started',
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_att_class FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE SET NULL,
  CONSTRAINT fk_att_tutor FOREIGN KEY(tutor_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_att_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL,
  INDEX idx_att_tutor(tutor_id),
  INDEX idx_att_checkin(check_in_at),
  INDEX idx_att_status(tutor_id,status)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('system','checkin','checkout','schedule','warning') NOT NULL DEFAULT 'system',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notifications_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user(user_id,is_read)
) ENGINE=InnoDB;

CREATE TABLE refresh_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  revoked_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_refresh_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_refresh_user(user_id),
  INDEX idx_refresh_expiry(expires_at)
) ENGINE=InnoDB;

-- Optional initial admin. Change the password through the API after deployment.
-- Do not insert a plaintext password here.
