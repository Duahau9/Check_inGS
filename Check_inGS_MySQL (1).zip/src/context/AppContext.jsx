import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [session, setSessionState] = useState(() => localStorage.getItem('access_token'))
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      if (!session) { setLoading(false); return }
      try {
        const result = await api.me()
        setProfile(result.user)
      } catch {
        localStorage.removeItem('access_token')
        setSessionState(null)
        setProfile(null)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [session])

  const setSession = (token) => {
    if (token) {
      localStorage.setItem('access_token', token)
      setSessionState(token)
    } else {
      localStorage.removeItem('access_token')
      setSessionState(null)
      setProfile(null)
    }
  }

  const value = useMemo(() => ({
    session: session ? { access_token: session } : null,
    profile, loading, setSession, setProfile
  }), [session, profile, loading])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}