import { NavLink } from 'react-router-dom'

export function Layout({ children, navItems = [], profile }) {
  return <div className="app-layout">
    <header className="app-header">
      <h1>Gia Sư Check-in</h1>
      <p>{profile?.full_name || profile?.email || 'Tài khoản'}</p>
    </header>
    <main className="app-content">{children}</main>
    <nav className="app-nav">
      {navItems.map(({to,label,icon:Icon}) => (
        <NavLink key={to} to={to} className={({isActive}) => `app-nav-item ${isActive ? 'active' : ''}`}>
          {Icon && <Icon size={20}/>}<span>{label}</span>
        </NavLink>
      ))}
    </nav>
  </div>
}