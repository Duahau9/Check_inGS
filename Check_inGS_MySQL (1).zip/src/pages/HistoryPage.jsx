import { useEffect,useState } from 'react'
import { getAttendanceHistoryForParent } from '../services/attendanceService'

export function HistoryPage(){
  const [items,setItems]=useState([]),[loading,setLoading]=useState(true)
  useEffect(()=>{getAttendanceHistoryForParent().then(r=>{if(!r.error)setItems(r.data||[]);setLoading(false)})},[])
  return <div className="grid"><div><h1>Lịch sử học</h1><p style={{color:'#6b7280'}}>Các buổi học đã check-in/check-out.</p></div>
    {loading?<div className="card">Đang tải...</div>:items.length===0?<div className="card">Chưa có lịch sử buổi học.</div>:
    items.map(x=><div className="card grid" key={x.id}><b>{x.check_in_at?new Date(x.check_in_at).toLocaleDateString('vi-VN'):'--'}</b><div>Check-in: {x.check_in_at?new Date(x.check_in_at).toLocaleTimeString('vi-VN'):'--'}</div><div>Check-out: {x.check_out_at?new Date(x.check_out_at).toLocaleTimeString('vi-VN'):'--'}</div><div>Thời gian: {x.total_seconds||0} giây</div></div>)}
  </div>
}