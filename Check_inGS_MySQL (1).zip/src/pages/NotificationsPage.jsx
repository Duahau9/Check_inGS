import { useEffect,useState } from 'react'
import { api } from '../lib/api'
export function NotificationsPage(){
 const [items,setItems]=useState([])
 useEffect(()=>{api.notifications().then(r=>setItems(r.notifications||[])).catch(()=>{})},[])
 return <div className="grid"><h1>Thông báo</h1>{items.length===0?<div className="card">Chưa có thông báo.</div>:items.map(x=><div className="card" key={x.id}><b>{x.title}</b><p>{x.message}</p></div>)}</div>
}