import { useEffect, useState } from 'react'
import { LogOut, MapPinned, CheckCircle2, Clock3 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useGeolocation, getGpsStatus } from '../hooks/useGeolocation'
import { checkInAttendance, checkOutAttendance, getTodayAttendanceForTutor } from '../services/attendanceService'

const duration = s => {
  if (!s) return '00:00:00'
  return [Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(v=>String(v).padStart(2,'0')).join(':')
}

export function TutorDashboard() {
  const { profile, setSession } = useApp()
  const { getLocation, location, error:gpsError, loading:gpsLoading } = useGeolocation()
  const [attendance,setAttendance]=useState(null), [busy,setBusy]=useState(false), [message,setMessage]=useState('')

  const refresh=async()=>{ const {data}=await getTodayAttendanceForTutor(); setAttendance(data?.attendance || data || null) }
  useEffect(()=>{refresh()},[])

  const logout=async()=>{ try { await fetch(`${import.meta.env.VITE_API_URL||'http://localhost:3001/api'}/auth/logout`,{method:'POST',headers:{Authorization:`Bearer ${localStorage.getItem('access_token')}`}}) } catch {} setSession(null) }

  const action=async(type)=>{
    setBusy(true);setMessage('')
    try {
      const c=await getLocation()
      const gps=getGpsStatus(c.accuracy)
      if(gps.level==='error') throw new Error('Vị trí chưa đủ chính xác. Hãy bật GPS chính xác.')
      const result=type==='in'
        ? await checkInAttendance(c.latitude,c.longitude,c.accuracy)
        : await checkOutAttendance(c.latitude,c.longitude,c.accuracy)
      if(result.error) throw result.error
      setMessage(type==='in'?'✓ Check-in thành công':'✓ Check-out thành công'); await refresh()
    } catch(e){setMessage(e.message||'Thao tác thất bại')}
    finally{setBusy(false)}
  }

  const checkedIn=attendance?.status==='working' || attendance?.status==='checked_in'
  const checkedOut=attendance?.status==='completed' || attendance?.status==='checked_out'

  return <div className="grid">
    <div className="row"><div><div style={{color:'#6b7280'}}>Xin chào</div><h1 style={{margin:'4px 0'}}>{profile?.full_name||'Gia sư'}</h1></div><button className="secondary" onClick={logout}><LogOut size={16}/> Đăng xuất</button></div>
    <section className="card grid">
      <div className="row"><strong><CheckCircle2 size={20}/> Trạng thái</strong><b>{checkedOut?'Đã check-out':checkedIn?'Đã check-in':'Chưa check-in'}</b></div>
      <div style={{display:'flex',gap:10}}><button className="primary" disabled={busy||checkedIn||checkedOut} onClick={()=>action('in')}>CHECK-IN</button><button className="secondary" disabled={busy||!checkedIn||checkedOut} onClick={()=>action('out')}>CHECK-OUT</button></div>
      {message && <div className={message.startsWith('✓')?'success':'error'}>{message}</div>}
    </section>
    <section className="card grid">
      <strong><MapPinned size={20}/> Vị trí</strong>
      <div>Độ chính xác: {location?`${location.accuracy.toFixed(0)}m`:'Chưa có dữ liệu'}</div>
      {gpsLoading&&<div>Đang xác định vị trí...</div>}{gpsError&&<div className="error">{gpsError}</div>}
      <strong><Clock3 size={20}/> Thời gian dạy</strong>
      <div style={{fontSize:24,fontWeight:800}}>{duration(attendance?.total_seconds)}</div>
    </section>
  </div>
}