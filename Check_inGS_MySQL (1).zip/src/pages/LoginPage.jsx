import { useState } from 'react'
import { api } from '../lib/api'
import { useApp } from '../context/AppContext'

export function LoginPage() {
  const { setSession, setProfile } = useApp()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ full_name:'', email:'', password:'', role:'tutor' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      const result = mode === 'login'
        ? await api.login({ email: form.email, password: form.password })
        : await api.register(form)
      setSession(result.accessToken)
      setProfile(result.user)
    } catch (err) { setError(err.message) }
    finally { setLoading(false) }
  }

  return <div style={{maxWidth:420,margin:'12vh auto',padding:24}} className="card">
    <h2 style={{textAlign:'center',marginTop:0}}>Gia Sư Check-in</h2>
    <p style={{textAlign:'center',color:'#6b7280'}}>{mode==='login'?'Đăng nhập tài khoản':'Tạo tài khoản mới'}</p>
    <form onSubmit={submit} className="grid">
      {mode==='register' && <label>Họ và tên<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} required/></label>}
      <label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/></label>
      <label>Mật khẩu<input type="password" minLength="6" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required/></label>
      {mode==='register' && <label>Loại tài khoản<select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
        <option value="tutor">Gia sư</option><option value="parent">Phụ huynh</option>
      </select></label>}
      {error && <div className="error">{error}</div>}
      <button className="primary" disabled={loading}>{loading?'Đang xử lý...':mode==='login'?'Đăng nhập':'Đăng ký'}</button>
    </form>
    <button className="secondary" style={{width:'100%',marginTop:12}} onClick={()=>{setMode(mode==='login'?'register':'login');setError('')}}>
      {mode==='login'?'Chưa có tài khoản? Đăng ký':'Đã có tài khoản? Đăng nhập'}
    </button>
  </div>
}