import { api } from '../lib/api'

export async function checkInAttendance(latitude, longitude, accuracy) {
  try { return { data: await api.checkIn({ latitude, longitude, accuracy }), error: null } }
  catch (error) { return { data: null, error } }
}

export async function checkOutAttendance(latitude, longitude, accuracy) {
  try { return { data: await api.checkOut({ latitude, longitude, accuracy }), error: null } }
  catch (error) { return { data: null, error } }
}

export async function getTodayAttendanceForTutor() {
  try { return { data: await api.today(), error: null } }
  catch (error) { return { data: null, error } }
}

export async function getAttendanceHistoryForParent() {
  try { return { data: await api.history(), error: null } }
  catch (error) { return { data: null, error } }
}