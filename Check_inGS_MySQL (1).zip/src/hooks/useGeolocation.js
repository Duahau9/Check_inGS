import { useCallback, useState } from 'react'

export function useGeolocation() {
  const [location, setLocation] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const getLocation = useCallback(() => new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      const e = new Error('Trình duyệt không hỗ trợ GPS.')
      setError(e.message); reject(e); return
    }
    setLoading(true); setError('')
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const value = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        }
        setLocation(value); setLoading(false); resolve(value)
      },
      (e) => {
        const message = e.code === 1 ? 'Bạn đã từ chối quyền định vị.' : 'Không thể xác định vị trí hiện tại.'
        setError(message); setLoading(false); reject(new Error(message))
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
    )
  }), [])

  return { location, error, loading, getLocation }
}

export function getGpsStatus(accuracy) {
  if (accuracy == null) return { level: 'warning', label: 'Không xác định' }
  if (accuracy <= 30) return { level: 'success', label: 'Độ chính xác tốt' }
  if (accuracy <= 100) return { level: 'warning', label: 'Cảnh báo độ chính xác' }
  return { level: 'error', label: 'Vị trí chưa đủ chính xác' }
}